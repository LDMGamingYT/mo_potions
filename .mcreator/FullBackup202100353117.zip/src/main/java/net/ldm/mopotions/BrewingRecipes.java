package net.ldm.mopotions;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;

import net.ldm.mopotions.init.MoPotionsModPotions;
import net.ldm.mopotions.init.MoPotionsModItems;

import java.lang.reflect.Method;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BrewingRecipes {
	public BrewingRecipes() {
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		try {
			// mth.invoke(null, basePotion, ingredient, result);
			Class clazz = net.minecraft.world.item.alchemy.PotionBrewing.class;
			Method mth = ObfuscationReflectionHelper.findMethod(clazz, "func_193357_a", Potion.class, Item.class, Potion.class);
			// Haste
			mth.invoke(null, Potions.THICK, MoPotionsModItems.FERMENTED_SUGAR, MoPotionsModPotions.HASTE_POTION);
			mth.invoke(null, MoPotionsModPotions.HASTE_POTION, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_HASTE_POTION);
			mth.invoke(null, MoPotionsModPotions.HASTE_POTION, Items.REDSTONE, MoPotionsModPotions.LONG_HASTE_POTION);
			// Mining Fatigue
			mth.invoke(null, MoPotionsModPotions.HASTE_POTION, Items.FERMENTED_SPIDER_EYE, MoPotionsModPotions.MINING_FATIGUE_POTION);
			mth.invoke(null, MoPotionsModPotions.STRONG_HASTE_POTION, Items.FERMENTED_SPIDER_EYE, MoPotionsModPotions.STRONG_MINING_FATIGUE_POTION);
			mth.invoke(null, MoPotionsModPotions.LONG_HASTE_POTION, Items.FERMENTED_SPIDER_EYE, MoPotionsModPotions.LONG_MINING_FATIGUE_POTION);
			mth.invoke(null, MoPotionsModPotions.MINING_FATIGUE_POTION, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_MINING_FATIGUE_POTION);
			mth.invoke(null, MoPotionsModPotions.MINING_FATIGUE_POTION, Items.REDSTONE, MoPotionsModPotions.LONG_MINING_FATIGUE_POTION);
			// Nausea
			mth.invoke(null, Potions.MUNDANE, Items.PUFFERFISH, MoPotionsModPotions.NAUSEA);
			mth.invoke(null, MoPotionsModPotions.NAUSEA, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_NAUSEA);
			mth.invoke(null, MoPotionsModPotions.NAUSEA, Items.REDSTONE, MoPotionsModPotions.LONG_NAUSEA);
			// Blindness
			mth.invoke(null, Potions.THICK, Items.INK_SAC, MoPotionsModPotions.BLINDNESS);
			mth.invoke(null, MoPotionsModPotions.BLINDNESS, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_BLINDNESS);
			mth.invoke(null, MoPotionsModPotions.BLINDNESS, Items.REDSTONE, MoPotionsModPotions.LONG_BLINDNESS);
			// Decay AKA Wither
			mth.invoke(null, Potions.POISON, Items.WITHER_ROSE, MoPotionsModPotions.DECAY);
			mth.invoke(null, MoPotionsModPotions.DECAY, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_DECAY);
			mth.invoke(null, MoPotionsModPotions.DECAY, Items.REDSTONE, MoPotionsModPotions.LONG_DECAY);
			// Resistance
			mth.invoke(null, Potions.FIRE_RESISTANCE, Items.FERMENTED_SPIDER_EYE, MoPotionsModPotions.RESISTANCE);
			mth.invoke(null, MoPotionsModPotions.RESISTANCE, Items.GLOWSTONE_DUST, MoPotionsModPotions.STRONG_RESISTANCE);
			mth.invoke(null, MoPotionsModPotions.RESISTANCE, Items.REDSTONE, MoPotionsModPotions.LONG_RESISTANCE);
		} catch (Throwable e) {
			System.err.println("ERROR WHILST INITILIZING BREWING RECIPES: " + e);
		}
	}
}

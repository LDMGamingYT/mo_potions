
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ldm.mopotions.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoPotionsModPotions {
	private static final List<Potion> REGISTRY = new ArrayList<>();
	public static final Potion HASTE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 3600, 0, false, true)).setRegistryName("haste_potion"));
	public static final Potion STRONG_HASTE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 1800, 1, false, true)).setRegistryName("strong_haste_potion"));
	public static final Potion LONG_HASTE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SPEED, 9600, 0, false, true)).setRegistryName("long_haste_potion"));
	public static final Potion MINING_FATIGUE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3600, 0, false, true)).setRegistryName("mining_fatigue_potion"));
	public static final Potion STRONG_MINING_FATIGUE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 1800, 1, false, true)).setRegistryName("strong_mining_fatigue_potion"));
	public static final Potion LONG_MINING_FATIGUE_POTION = register(
			new Potion(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 9600, 0, false, true)).setRegistryName("long_mining_fatigue_potion"));
	public static final Potion NAUSEA = register(
			new Potion(new MobEffectInstance(MobEffects.CONFUSION, 3600, 0, false, true)).setRegistryName("nausea"));
	public static final Potion STRONG_NAUSEA = register(
			new Potion(new MobEffectInstance(MobEffects.CONFUSION, 1800, 1, false, true)).setRegistryName("strong_nausea"));
	public static final Potion LONG_NAUSEA = register(
			new Potion(new MobEffectInstance(MobEffects.CONFUSION, 9600, 0, false, true)).setRegistryName("long_nausea"));
	public static final Potion BLINDNESS = register(
			new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 3600, 0, false, true)).setRegistryName("blindness"));
	public static final Potion STRONG_BLINDNESS = register(
			new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 1800, 1, false, true)).setRegistryName("strong_blindness"));
	public static final Potion LONG_BLINDNESS = register(
			new Potion(new MobEffectInstance(MobEffects.BLINDNESS, 9600, 0, false, true)).setRegistryName("long_blindness"));
	public static final Potion DECAY = register(new Potion(new MobEffectInstance(MobEffects.WITHER, 3600, 0, false, true)).setRegistryName("decay"));
	public static final Potion STRONG_DECAY = register(
			new Potion(new MobEffectInstance(MobEffects.WITHER, 1800, 1, false, true)).setRegistryName("strong_decay"));
	public static final Potion LONG_DECAY = register(
			new Potion(new MobEffectInstance(MobEffects.WITHER, 9600, 0, false, true)).setRegistryName("long_decay"));
	public static final Potion RESISTANCE = register(
			new Potion(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 0, false, true)).setRegistryName("resistance"));
	public static final Potion LONG_RESISTANCE = register(
			new Potion(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 9600, 0, false, true)).setRegistryName("long_resistance"));
	public static final Potion STRONG_RESISTANCE = register(
			new Potion(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1800, 1, false, true)).setRegistryName("strong_resistance"));

	private static Potion register(Potion potion) {
		REGISTRY.add(potion);
		return potion;
	}

	@SubscribeEvent
	public static void registerPotions(RegistryEvent.Register<Potion> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Potion[0]));
	}
}

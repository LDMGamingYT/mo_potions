
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ldm.mopotions.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.ldm.mopotions.item.FermentedSugarItem;
import net.ldm.mopotions.item.AngelTotemItem;
import net.ldm.mopotions.MoPotionsMod;

public class MoPotionsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MoPotionsMod.MODID);
	public static final RegistryObject<Item> FERMENTED_SUGAR = REGISTRY.register("fermented_sugar", () -> new FermentedSugarItem());
	public static final RegistryObject<Item> ANGEL_TOTEM = REGISTRY.register("angel_totem", () -> new AngelTotemItem());
}
